from django.shortcuts import render
import os
from pathlib import Path
from dotenv import load_dotenv
import openai
from openai import OpenAI


#1. 키 가져오기
BASE_DIR= Path(__file__).resolve().parent.parent.parent.parent
load_dotenv(BASE_DIR/'.env')
api_key = os.getenv('open_ai_key')

client = OpenAI(api_key=api_key)

# text = {
#     "경주": "신라 천년의 수도로, 불국사와 석굴암, 첨성대, 대릉원 등 역사 유적이 도시 곳곳에 있는 곳이에요.",
#     "정선": "강원도 산골의 자연과 정선아리랑, 정선5일장, 레일바이크로 유명한 여행지예요.",
#     "설악산": "강원도의 대표 국립공원으로 울산바위, 권금성, 가을 단풍이 유명해요.",
# }


#2. 검색어 입력부분
def tour(request):
    return render(request,'tour.html')